package corejava.advance.training;
import java.util.*;
public class EvenNumbers {

	public static void main(String[] args) 
	{
		Scanner s = new Scanner(System.in);
		System .out.println("Enter the Number: ");
		int n =s.nextInt();
		System.out.println("Even Numbers Are:");
		for(int i=0;i<=n;i++)
		{
			if(i%2==0)
			{
				System.out.println(i);
			
			}
		}
	}
}
