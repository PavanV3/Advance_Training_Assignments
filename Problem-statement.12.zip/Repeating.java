package problem.DayTwo;

import java.util.HashSet;

public class Repeating {
	static void printFirstRepeating(int arr[])
	{
		int min = -1;
	    HashSet<Integer> set = new HashSet<>();
	    for (int i=arr.length-1; i>=0; i--)
	    {
	    	if (set.contains(arr[i]))
	    		min = i;
	    	else   
	            set.add(arr[i]);
	        }
	        if (min != -1)
	          System.out.println("The first repeating element is: " + arr[min]);
	        else
	          System.out.println("No repeating elements in the array");
	    }
	 public static void main (String[] args) throws java.lang.Exception
	    {
	        int arr[] = {11,2,2,33,22,54,54};
	        printFirstRepeating(arr);	        
	        int arr1[] = {11,2,23,33,54,54};
	        printFirstRepeating(arr1);
	        int arr2[] = {11,2,23,33,54};
	        printFirstRepeating(arr2);
	        
	    }
	}

